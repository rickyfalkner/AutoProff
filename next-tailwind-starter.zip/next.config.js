/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    turboMode: false,
  },
}
module.exports = nextConfig
