export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center p-24">
      <h1 className="text-4xl font-bold">Next.js 14 + Tailwind Starter</h1>
    </main>
  );
}
